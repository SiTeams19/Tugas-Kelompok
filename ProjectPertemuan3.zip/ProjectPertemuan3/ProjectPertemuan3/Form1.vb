﻿Public Class Form1
    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TxtKet.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles CmdProses.Click
        Dim Ket As String
        Ket = ""
        If Val(TxtNA.Text) >= 56 Then
            Ket = "LULUS"
        Else
            Ket = "TIDAK LULUS"
        End If
        TxtKet.Text = Ket
    End Sub
End Class
